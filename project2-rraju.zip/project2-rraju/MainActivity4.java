package com.example.project2_rraju;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity4 extends AppCompatActivity {
    ListView listView;
    ArrayAdapter myAdapter;
    public ArrayList<String> array;
    public ArrayList<String> results;
    public Cursor mCursor;
    public SQLiteDatabase db;
    DBClassAsync2 dbClassAsync;
    public String item;
    public int reps;
    public int sets;
    public int weights;
    public String notes;

    private final class DBClassAsync2 extends AsyncTask<String, Void, Cursor> {
        // runs on the UI thread
        @SuppressLint("Range")
        @Override protected void onPostExecute(Cursor data) {

            results  = new ArrayList<>();
            if (data != null ) {
                Log.e("data", String.valueOf(data));
                if  (data.moveToFirst()) {
                    do {
                        results.add(data.getString(data.getColumnIndex(LoadDB.COL_EXERCISE)));
                    }while (data.moveToNext());
                }

            }

            myAdapter = new ArrayAdapter<String>(MainActivity4.this, R.layout.line, results);
            listView.setAdapter(myAdapter);
            mCursor = data;
        }
        // runs on its own thread
        @Override
        protected Cursor doInBackground(String... args) {
            String queryString = "SELECT * FROM " + LoadDB.TABLE_NAME;
            LoadDB dbClass = new LoadDB(MainActivity4.this);
            db = dbClass.getWritableDatabase();
            return db.rawQuery(queryString, null);
        }
    }

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        array = new ArrayList<String>();
        listView = (ListView) findViewById(R.id.mylist);
        myAdapter = new ArrayAdapter<String>(this, R.layout.line, array);
        listView.setAdapter(myAdapter);
        Log.e("this", String.valueOf(MainActivity4.this));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("this inner", String.valueOf(MainActivity4.this.reps));
                item = (String) ((TextView) view).getText();
                getValues(item);
                Snackbar snackbar = Snackbar.make(view, "You clicked on " + item + "\n Reps="+ MainActivity4.this.reps +" Sets= "+MainActivity4.this.sets , Snackbar.LENGTH_INDEFINITE);
                snackbar.show();
            }
        } );
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                                                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                                                    alertView("Single Item Deletion",position);
                                                    return true;
                                                }
                                            }
        );
    }
    @SuppressLint("Range")
    public void getValues(String item){
        String queryString = "SELECT * FROM " + LoadDB.TABLE_NAME + " WHERE " + LoadDB.COL_EXERCISE + " = \"" + item + "\"";
        LoadDB dbClass = new LoadDB(MainActivity4.this);
        SQLiteDatabase db = dbClass.getWritableDatabase();
        Cursor c = db.rawQuery(queryString, null);
        if (c != null) {

            if (c.moveToFirst()) {

                this.reps = (c.getInt(c.getColumnIndex(LoadDB.COL_REPS)));
                Log.e("reps", String.valueOf(reps));
                this.sets = (c.getInt(c.getColumnIndex(LoadDB.COL_SETS)));
                Log.e("sets", String.valueOf(sets));
                this.weights = (c.getInt(c.getColumnIndex(LoadDB.COL_WEIGHT)));
                Log.e("weights", String.valueOf(weights));
                this.notes = (c.getString(c.getColumnIndex(LoadDB.COL_NOTES)));
                Log.e("notes", String.valueOf(notes));

            }

        }
    }
    protected void onResume(){
        super.onResume();
        dbClassAsync = new MainActivity4.DBClassAsync2();
        dbClassAsync.execute();
    }
    protected  void onStop(){
        super.onStop();
        mCursor.close();
        db.close();
    }
//
//    public void blah(View view) {
//        String item = "hi";
//        Snackbar snackbar = Snackbar.make(view, "You clicked on " + item + "\n Reps="+ reps +" Sets= "+String.valueOf(sets) , Snackbar.LENGTH_INDEFINITE);
//        snackbar.show();
//    }
    private void alertView(String message ,final int position) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity4.this);
        dialog.setTitle( message )
                .setIcon(R.drawable.ic_launcher_background)
                .setMessage("Are you sure you want to do this?")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialoginterface, int i) {
                        dialoginterface.cancel();
                    }})
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialoginterface, int i) {
                        LoadDB dbClass = new LoadDB(MainActivity4.this);
                        Log.e("i", String.valueOf(position));
                        String exercise = results.get(position);
                        dbClass.deleteTask(db, exercise);
                        Toast.makeText(MainActivity4.this, "Deleted successfully",Toast.LENGTH_SHORT).show();
                        dbClassAsync = new DBClassAsync2();
                        dbClassAsync.execute();
                    }
                }).show();
    }

}
