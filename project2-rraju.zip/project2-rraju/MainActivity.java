package com.example.project2_rraju;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void onClickWorkout(View view) {
        Intent activity2Intent = new Intent(getApplicationContext(), MainActivity4.class);
        startActivity(activity2Intent);
    }

    public void onClickEdit(View view) {
        Intent activity2Intent = new Intent(getApplicationContext(), MainActivity1.class);
        startActivity(activity2Intent);
    }
}