package com.example.project2_rraju;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity2 extends AppCompatActivity {
    EditText repsText;
    EditText setsText;
    EditText weightsText;
    EditText notesText;
    String value;
    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int reps = 0;
        int sets = 0;
        int weights = 0;
        String notes = "";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        value = getIntent().getExtras().getString("exerciseName");
        Log.e("value", value);
        TextView t = findViewById(R.id.name);
        t.setText(value);
        TextView t1 = findViewById(R.id.textView3);
        t1.setText("Update value of "+value);
        String queryString = "SELECT * FROM " + LoadDB.TABLE_NAME + " WHERE "+LoadDB.COL_EXERCISE + " = \""+ value + "\"";
        LoadDB dbClass = new LoadDB(MainActivity2.this);
        SQLiteDatabase db = dbClass.getWritableDatabase();
        Cursor c =  db.rawQuery(queryString, null);
        if (c != null ) {

            if  (c.moveToFirst()) {

                reps = (c.getInt(c.getColumnIndex(LoadDB.COL_REPS)));
                Log.e("reps", String.valueOf(reps));
                sets = (c.getInt(c.getColumnIndex(LoadDB.COL_SETS)));
                Log.e("sets", String.valueOf(sets));
                weights = (c.getInt(c.getColumnIndex(LoadDB.COL_WEIGHT)));
                Log.e("weights", String.valueOf(weights));
                notes = (c.getString(c.getColumnIndex(LoadDB.COL_NOTES)));
                Log.e("notes", String.valueOf(notes));


            }
            repsText =  findViewById(R.id.reps);
            repsText.setText(String.valueOf(reps));
            repsText.setInputType(InputType.TYPE_CLASS_NUMBER);
            setsText = findViewById(R.id.sets);
            setsText.setText(String.valueOf(sets));
            setsText.setInputType(InputType.TYPE_CLASS_NUMBER);
            weightsText = findViewById(R.id.weight);
            weightsText.setText(String.valueOf(weights));
            weightsText.setInputType(InputType.TYPE_CLASS_NUMBER);
            notesText = findViewById(R.id.notes);
            notesText.setText(String.valueOf(notes));

        }


    }
    public void onClickUpdate(View view){
        int reps = Integer.parseInt(String.valueOf(repsText.getText()));
        int sets = Integer.parseInt(String.valueOf(setsText.getText()));
        int weights = Integer.parseInt(String.valueOf(weightsText.getText()));
        String notes = String.valueOf(notesText.getText());
        LoadDB dbclass = new LoadDB(MainActivity2.this);
        boolean success = dbclass.updateOne(value, sets, reps, weights, notes);
        Log.e("success", String.valueOf(success));
        finish();


    }
    public void onClickCancel(View view){
        finish();
    }
}
