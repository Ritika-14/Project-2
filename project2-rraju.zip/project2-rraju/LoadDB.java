package com.example.project2_rraju;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class LoadDB extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "exercise_list";
    public static final String COL_ID= "exercise_id";
    public static final String COL_EXERCISE = "exercise";
    public static final String COL_SETS = "sets";
    public static final String COL_REPS = "reps";
    public static final String COL_WEIGHT = "weight";
    public static final String COL_NOTES = "notes";
    private static final int DB_VERSION = 7;
    private static final String CREATE_CMD = "CREATE TABLE " + TABLE_NAME + "("

            + COL_ID +" TEXT PRIMARY KEY, " + COL_EXERCISE + " TEXT NOT NULL, "+COL_SETS + " INTEGER, "+ COL_REPS+ " INTEGER, "+ COL_WEIGHT+" INTEGER, "+COL_NOTES+" TEXT "+" ) ";

    public LoadDB(@Nullable Context context) {
        super(context, TABLE_NAME,null,DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_CMD);
        ContentValues cv = new ContentValues(6);
        cv.put(COL_ID, "situps");
        cv.put(COL_EXERCISE, "Situps");
        cv.put(COL_SETS, 2);
        cv.put(COL_REPS, 10);
        cv.put(COL_WEIGHT, 10);
        cv.put(COL_NOTES, "Use good form");
        db.insert(TABLE_NAME,null ,cv);
        cv.put(COL_ID, "pushups");
        cv.put(COL_EXERCISE, "Pushups");
        cv.put(COL_SETS, 2);
        cv.put(COL_REPS, 10);
        cv.put(COL_WEIGHT, 10);
        cv.put(COL_NOTES, "Work harder");
        db.insert(TABLE_NAME,null ,cv);
        cv.put(COL_ID, "bicep_curls");
        cv.put(COL_EXERCISE, "Bicep Curls");
        cv.put(COL_SETS, 2);
        cv.put(COL_REPS, 10);
        cv.put(COL_WEIGHT, 10);
        cv.put(COL_NOTES, "Use good form");
        db.insert(TABLE_NAME,null ,cv);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
    public boolean addOne( String exercise, String id, int sets, int reps, int weight, String notes){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues(6);
        cv.put(COL_ID,id );
        cv.put(COL_EXERCISE, exercise);
        cv.put(COL_SETS, sets);
        cv.put(COL_REPS, reps);
        cv.put(COL_WEIGHT, weight);
        cv.put(COL_NOTES, notes);
        long insert = db.insert(TABLE_NAME,null ,cv);
        if(insert==-1)
            return false;
        return true;

    }
    public boolean updateOne( String exercise, int sets, int reps, int weight, String notes){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues(5);
        cv.put(COL_ID, exercise);
        cv.put(COL_SETS, sets);
        cv.put(COL_REPS, reps);
        cv.put(COL_WEIGHT, weight);
        cv.put(COL_NOTES, notes);
        int success = db.update(TABLE_NAME, cv, "exercise = ?", new String[]{exercise});

        if(success==-1)
            return false;
        return true;

    }
    public void deleteTask(SQLiteDatabase db1, String exercise){
        db1.delete(TABLE_NAME, COL_EXERCISE + "=?", new String[]{exercise});

    }
}
