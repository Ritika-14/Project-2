package com.example.project2_rraju;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity1 extends AppCompatActivity {
    ListView listView;
    ArrayAdapter myAdapter;
    public ArrayList<String> array;
    Cursor mCursor;
    SQLiteDatabase db;
    ArrayList<String > results;
    DBClassAsync dbClassAsync;

    private final class DBClassAsync extends AsyncTask<String, Void, Cursor> {
        // runs on the UI thread
        @SuppressLint("Range")
        @Override protected void onPostExecute(Cursor data) {

            results  = new ArrayList<>();
            if (data != null ) {
                Log.e("data", String.valueOf(data));
                if  (data.moveToFirst()) {
                    do {
                        results.add(data.getString(data.getColumnIndex(LoadDB.COL_EXERCISE)));
                    }while (data.moveToNext());
                }

            }

            myAdapter = new ArrayAdapter<String>(MainActivity1.this, R.layout.line, results);
            listView.setAdapter(myAdapter);
            mCursor = data;
        }
        // runs on its own thread
        @Override
        protected Cursor doInBackground(String... args) {
            String queryString = "SELECT * FROM " + LoadDB.TABLE_NAME;
            LoadDB dbClass = new LoadDB(MainActivity1.this);
            db = dbClass.getWritableDatabase();
            return db.rawQuery(queryString, null);
        }
    }

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.mylist);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(), "Item " + ((TextView) view).getText(), Toast.LENGTH_SHORT).show();
                String item = (String) ((TextView) view).getText();
                Log.e("item", item);
                Intent activity2Intent = new Intent(getApplicationContext(), MainActivity2.class);

                activity2Intent.putExtra("exerciseName", item);
                startActivity(activity2Intent);


            }
        });
    }
    public void onClickAdd(View view){
        Intent activity2Intent = new Intent(getApplicationContext(), MainActivity3.class);
        startActivity(activity2Intent);

    }
    protected void onResume() {
        super.onResume();
        dbClassAsync = new DBClassAsync();
        dbClassAsync.execute();
    }
    protected  void onStop(){
        super.onStop();
        mCursor.close();
        db.close();
    }

}