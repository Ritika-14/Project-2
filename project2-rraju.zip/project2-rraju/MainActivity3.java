package com.example.project2_rraju;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.project2_rraju.databinding.ActivityMain6Binding;

public class MainActivity3 extends AppCompatActivity {
    public EditText name;
    public EditText reps;
    public EditText sets;
    public EditText weight;
    public EditText notes;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        reps =  (EditText)findViewById(R.id.reps);
        reps.setInputType(InputType.TYPE_CLASS_NUMBER);
        sets = (EditText)findViewById(R.id.sets);
        sets.setInputType(InputType.TYPE_CLASS_NUMBER);
        weight = (EditText)findViewById(R.id.weight);
        weight.setInputType(InputType.TYPE_CLASS_NUMBER);

    }

    public void addToWorkout(View view) {
        int repsName;
        int setsName;
        int weightName;
        String notesName;
        name =  (EditText)findViewById(R.id.exerciseName);
        String exerciseName = name.getText().toString();
        if(name.getText().toString().equals(""))
            Toast.makeText(getApplicationContext(), "Please enter valid exercise name", Toast.LENGTH_LONG).show();
        String id = exerciseName.trim().replaceAll(" ", "_").replaceAll("-", "_").toLowerCase();

        if(reps.getText().toString().equals(""))
            repsName = 10;
        else
            repsName = Integer.parseInt(reps.getText().toString());



        if(sets.getText().toString().equals(""))
            setsName = 2;
        else
            setsName=Integer.parseInt(sets.getText().toString());


        if(weight.getText().toString().equals(""))
            weightName = 4;
        else
            weightName = Integer.parseInt(weight.getText().toString());

        notes = (EditText)findViewById(R.id.notes);
        if(notes.getText().toString().equals(""))
            notesName = "Try hard";
        else
           notesName = notes.getText().toString();

        LoadDB dbclass = new LoadDB(MainActivity3.this);
        if(!exerciseName.equals("")) {

                boolean success = dbclass.addOne(exerciseName, id, setsName, repsName, weightName, notesName);
                if (success == false)
                    Toast.makeText(getApplicationContext(), "Duplicate entry not allowed", Toast.LENGTH_LONG).show();
                else {
                    finish();
                }
            }




    }
    public void onCancel(View view){
        finish();
    }
}